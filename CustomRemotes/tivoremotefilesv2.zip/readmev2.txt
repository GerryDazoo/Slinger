Custom Tivo remote for slinger.

Intalation…

Copy both the TIVOremotePFv2.html file and the tivoremotefilesv2 directory into your slinger server folder so you have the TivoremotePFv2.html and a subfolder tivoremotefilesv2 in your slinger servers main directory.

Edit the config.ini file’s ”include” directive to read:  include=TIVORemotePFv2.html
remember to remove the “;” infront of the word include if it is there.

Customize…

For the two dropdown menus, used for quick channel changes, you might need to change the channel assignments for your local cable setup.  There are two long lines of code in the TIVORemote.html file that start with “var data =“. These are the json data mapping your channel number and channel name i.e. {"id":"802","text":"PBS WPBT 2"}.   Change the numbers to coincid with your tv channel lineup and change the channel name as desired. You can also delete entries, add entries or reorder, etc.. These two json data entries can be different or the same, one shows on the main remote and one on the mini remote. Do not delete the first json entry… {"id":"","text":""}. Do not change the words ‘id’ or ‘text’. Please note the format of this line is important, leave all the quotes and brackets and commas as they are.  If deleting an entry, delete all of, for example “{"id":"802","text":"PBS WPBT 2"}”, including the brackets, for example your var data line could read as…  

		var data = [{"id":"","text":""},{"id":"802","text":"PBS WPBT"},{"id":"804","text":"CBS WFOR"}]; 


Usage…

Click any of the zoom buttons at the top to change the remote size from mini, small, large.   Defaults to small in the code.
Click any button on the remote.
The letters "last" on the remote under the "enter" key are mapped to the "last" keycode, cick on the letters "last" for this.
Use the dropdown box at the botton to search and change to a channel - see above to customize your channel lineup.
Note, when using the dropdown, you do not need to sumbit, the channel will change right after you pick an entry.  If your cable box requires "sel" after entering a channel change, please add: "sendKeys('42','sel')" without the double quotes, to the bottom of the "sendDigit()" function - see the example below.


Enjoy.


adding "sel" to channel change sample....

function sendDigits3(){
		var digit = $('#Digit3').val();
		$.ajax({
			data: {Digits : digit},
			type: "POST",
			cache: false,
			success: function (response) {
			}
		});
	sendKeys('42','sel')
	}